<div class="card-header" id="card-reservas" style="width: 100%; background-color: white; display: flex; flex-wrap: wrap;">
    <div class="tab-pane" id="tabs-Reserva" role="tabpanel">
        <div class="card">
            <div class="card-header" style="width: 100%; background-color: #1d2736">
                <div class="row" style="width: 100%;">
                    <div class="col-12 col-sm-8">
                        <h3 class="card-title" style="color: white; font-weight: bold;">RESERVAS HABITACIONES</h3>
                    </div>
                    <div class="col-12 col-sm-4" style="text-align: right;">
                        <a class="btn" id="addreservas">+ Nueva Reserva</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="datagrid">
                    <div class="datagrid-item">
                        <div class="row">
                            <div class="col-12 col-sm-12" style="width: 100%; background: #F5F7F8; padding-top: 10px; padding-bottom: 10px">
                                <div class="row" style="background: #F5F7F8;">
                                    <div class="col-2 col-md-1" style="border-right: 2px solid #E6E6E6;">
                                        <center>
                                            <div class="icon-container">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-filter">
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                                    <path d="M4 4h16v2.172a2 2 0 0 1 -.586 1.414l-4.414 4.414v7l-6 2v-8.5l-4.48 -4.928a2 2 0 0 1 -.52 -1.345v-2.227z" />
                                                </svg>
                                            </div>
                                        </center>
                                    </div>
                                    <div class="col-md-10">
                                        <div class="row" style="padding-bottom: 10px">
                                            <div class="col-md-3">
                                                <select name="DateReserva" id="DateReserva" class="form-control">
                                                    <option value="DiarioReserva">Diario</option>
                                                    <option value="MensualReserva">Mensual</option>
                                                    <option value="AnualReserva">Anual</option>
                                                    <option value="RangoReserva">Rango</option>
                                                </select>
                                            </div>
                                            <div class="col-md-1" id="DiaReservaContainer">
                                                <select name="DiaReserva" id="DiaReserva" class="form-control">
                                                </select>
                                            </div>
                                            <div class="col-md-2" id="MesReservaContainer">
                                                <select name="MesReserva" id="MesReserva" class="form-control">
                                                </select>
                                            </div>
                                            <div class="col-md-2" id="AnioReservaContainer">
                                                <select name="AnioReserva" id="AnioReserva" class="form-control">
                                                </select>
                                            </div>
                                            <div class="col-md-3" id="FechaInicioContainerReserva">
                                                <input type="date" name="fechaInicioReserva" id="fechaInicioReserva" class="form-control">
                                            </div>
                                            <div class="col-md-3" id="FechaFinContainerReserva">
                                                <input type="date" name="fechaFinReserva" id="fechaFinReserva" class="form-control">
                                            </div>
                                            <div class="col-md-2" id="FechaFinContainerReserva">
                                                <select name="TipoReserva" id="TipoReserva" class="form-control">
                                                    <option value="TodoReserva">Estado Reserva</option>
                                                    <option value="Concluido">Concluido</option>
                                                    <option value="En Espera">En Espera</option>
                                                    <option value="Cancelado">Cancelado</option>
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <select name="Habitaciones" id="Habitaciones" class="form-control">
                                                    <option value="TodoHabitaciones">Habitaciones</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12" style="width: 100%; margin: 0px; border-bottom: 1px solid #E6E6E6; border-left: 1px solid #E6E6E6; border-right: 1px solid #E6E6E6;">
                                <div class="row">
                                    <div class="col-10 col-md-12" style="border-top: 2px solid #E6E6E6;">
                                        <div class="row" style="padding-top: 8px;" >
                                            <div class="row" style="width: 100%;">
                                                <div class="col-md-12" style="border-right: 2px solid #E6E6E6; border-bottom: 1px solid #E6E6E6; padding: 10px">
                                                    <span style="color: #7F8487; font-weight: bold;">Reservas existentes para esta fecha
                                                        <span style="color: #2C3333; font-weight: bold; font-size: 22px"id="SpanCantidad"></span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12" style="width: 100%; padding-top: 15px; margin: 0px;">
                                <div class="row">
                                    <div class="col-12 col-sm-12">
                                        <div class="card">
                                            <div class="table-responsive" id="tabla-Reserva">
                                                <table class="table table-vcenter card-table">
                                                        <thead>
                                                            <tr>
                                                            <th>Codigo Reserva</th>
                                                            <th>Habitacion</th>
                                                            <th>CheckIn</th>
                                                            <th>ChexkOut</th>
                                                            <th>Comentario</th>
                                                            <th>Estado</th>
                                                            </tr>
                                                        </thead>
                                                    <tbody>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .selected-row {
        background-color: #FFEEAD;
    }
</style>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="{{ asset('utilidades/js/hostal/hospedajehabitacion.js') }}" defer></script>
<script src="{{ asset('utilidades/js/hostal/ocupadohabitacion.js') }}" defer></script>
<script src="{{ asset('utilidades/js/hostal/reservashabitaciones.js') }}" defer></script>
<script src="{{ asset('utilidades/js/InputClass.js') }}" defer></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
