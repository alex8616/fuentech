@extends('layouts.my-dashboard-layout-hostal')

@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">

<div class="row">
    <div class="col-12 col-sm-7">
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs nav-fill" data-bs-toggle="tabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a href="#tabs-habitaciones" class="nav-link active" data-bs-toggle="tab" aria-selected="false" role="tab">AMBIENTES</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">RESERVAS</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#tabs-reservas-habitaciones" data-bs-toggle="tab" role="tab">
                                Habitación
                            </a>
                            <a class="dropdown-item" href="#tabs-reservas-salones" data-bs-toggle="tab" role="tab">
                                Salón
                            </a>
                        </div>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a href="#tabs-reservas-grupos" class="nav-link" data-bs-toggle="tab" aria-selected="false" role="tab">GRUPOS</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a href="#tabs-deudas-habitaciones" class="nav-link" data-bs-toggle="tab" aria-selected="false" role="tab">DEUDAS</a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane active show" id="tabs-habitaciones" role="tabpanel">
                        @include('admin.Hostal.Habitaciones')
                    </div>
                    <div class="tab-pane" id="tabs-reservas-habitaciones" role="tabpanel">
                        @include('admin.Hostal.ReservasHabitaciones')
                    </div>
                    <div class="tab-pane" id="tabs-reservas-salones" role="tabpanel">
                        @include('admin.Hostal.ReservasSalones')
                    </div>
                    <div class="tab-pane" id="tabs-reservas-grupos" role="tabpanel">
                        @include('admin.Hostal.ReservasGrupo')
                    </div>
                    <div class="tab-pane" id="tabs-deudas-habitaciones" role="tabpanel">
                        @include('admin.Hostal.DeudasHabitacion')
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-5" style="margin: 0px; padding: 0px;">
        <div class="card" id="form_tabs">
            <div class="card-header">
                <h3 class="card-title">. . .</h3>
            </div>
            <div class="card-body">
                <div class="datagrid"></div>
            </div>
        </div>
    </div>
</div>
@endsection

@livewireStyles
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function() {
        function getBaseUrl() {
            var url = window.location.href;
            return url.split('#')[0];
        }

        function updateUrl(tabId) {
            var newUrl = getBaseUrl() + tabId;
            window.history.replaceState(null, null, newUrl);
        }

        $('.nav-link:not(.dropdown-toggle)').on('click', function(e) {
            var tabId = $(this).attr('href');
            updateUrl(tabId);
        });

        $('.dropdown-item').on('click', function(e) {
            e.preventDefault();
            var tabId = $(this).attr('href');
            updateUrl(tabId);
            $(tabId).tab('show');
        });

        var currentHash = window.location.hash;
        if (currentHash) {
            $(currentHash).tab('show');
        }

        $('.dropdown-menu').removeClass('show');

        $('.nav-item.dropdown').on('hidden.bs.dropdown', function() {
            $('.dropdown-menu').removeClass('show');
        });
    });
</script>
@livewireScripts
